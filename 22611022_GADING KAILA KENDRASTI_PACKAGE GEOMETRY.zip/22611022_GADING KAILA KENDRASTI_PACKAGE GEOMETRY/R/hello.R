# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

# Fungsi untuk menghitung keliling berbagai bentuk geometri
calculate_perimeter <- function(shape, ...) {
  if (shape == "square") {
    args <- list(...)
    if (length(args) != 1) stop("Untuk persegi, masukkan hanya 1 argumen: sisi.")
    s <- args[[1]]
    perimeter <- 4 * s
  } else if (shape == "rectangle") {
    args <- list(...)
    if (length(args) != 2) stop("Untuk persegi panjang, masukkan 2 argumen: panjang dan lebar.")
    l <- args[[1]]
    w <- args[[2]]
    perimeter <- 2 * (l + w)
  } else if (shape == "triangle") {
    args <- list(...)
    if (length(args) != 3) stop("Untuk segitiga, masukkan 3 argumen: sisi a, sisi b, dan sisi c.")
    a <- args[[1]]
    b <- args[[2]]
    c <- args[[3]]
    perimeter <- a + b + c
  } else if (shape == "circle") {
    args <- list(...)
    if (length(args) != 1) stop("Untuk lingkaran, masukkan hanya 1 argumen: radius.")
    r <- args[[1]]
    perimeter <- 2 * pi * r
  } else {
    stop("Jenis bentuk tidak dikenali. Gunakan 'square', 'rectangle', 'triangle', atau 'circle'.")
  }
  return(perimeter)
}

# Fungsi untuk menghitung luas berbagai bentuk geometri
calculate_area <- function(shape, ...) {
  if (shape == "square") {
    args <- list(...)
    if (length(args) != 1) stop("Untuk persegi, masukkan hanya 1 argumen: sisi.")
    s <- args[[1]]
    area <- s^2
  } else if (shape == "rectangle") {
    args <- list(...)
    if (length(args) != 2) stop("Untuk persegi panjang, masukkan 2 argumen: panjang dan lebar.")
    l <- args[[1]]
    w <- args[[2]]
    area <- l * w
  } else if (shape == "triangle") {
    args <- list(...)
    if (length(args) != 2) stop("Untuk segitiga, masukkan 2 argumen: alas dan tinggi.")
    b <- args[[1]]
    h <- args[[2]]
    area <- 0.5 * b * h
  } else if (shape == "circle") {
    args <- list(...)
    if (length(args) != 1) stop("Untuk lingkaran, masukkan hanya 1 argumen: radius.")
    r <- args[[1]]
    area <- pi * r^2
  } else {
    stop("Jenis bentuk tidak dikenali. Gunakan 'square', 'rectangle', 'triangle', atau 'circle'.")
  }
  return(area)
}


setwd("path/to/geometry")
install.packages("devtools")
library(devtools)
document()
build()
install.packages("geometry_0.1.0.tar.gz", repos = NULL, type = "source")
library(geometry)



# Menghitung keliling
keliling_persegi <- calculate_perimeter("square", 6)
cat("Keliling Persegi:", keliling_persegi, "\n")

keliling_persegi_panjang <- calculate_perimeter("rectangle", 10, 6)
cat("Keliling Persegi Panjang:", keliling_persegi_panjang, "\n")

keliling_segitiga <- calculate_perimeter("triangle", 9, 16, 25)
cat("Keliling Segitiga:", keliling_segitiga, "\n")

keliling_lingkaran <- calculate_perimeter("circle", 28)
cat("Keliling Lingkaran:", keliling_lingkaran, "\n")

# Menghitung luas
luas_persegi <- calculate_area("square", 6)
cat("Luas Persegi:", luas_persegi, "\n")

luas_persegi_panjang <- calculate_area("rectangle", 6, 3)
cat("Luas Persegi Panjang:", luas_persegi_panjang, "\n")

luas_segitiga <- calculate_area("triangle", 6, 8)
cat("Luas Segitiga:", luas_segitiga, "\n")

luas_lingkaran <- calculate_area("circle", 28)
cat("Luas Lingkaran:", luas_lingkaran, "\n")

